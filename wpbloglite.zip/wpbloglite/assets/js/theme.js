jQuery(window).on('scroll', function () {
    //fixed header 
    if (jQuery(window).scrollTop() > jQuery('#header').outerHeight() + 200) {
        jQuery('#header').addClass('header-fixed');
    } else {
        jQuery('#header').removeClass('header-fixed');
    }
});
jQuery(document).ready(function () {
    //add dropdown button to menu who has children
    jQuery('.navbar .menu-item-has-children > a').after('<button type="button" class="dropdown-btn"></button>');
    // Dropdown button click show submenu
    // jQuery('.navbar > #menu-primary > .menu-item-has-children > .dropdown-btn').on('click', function () {
    //     if (jQuery(this).hasClass('active')) {
    //         jQuery(this).next('.sub-menu').slideUp('slow');
    //         jQuery(this).removeClass('active');
    //     } else {
    //         jQuery('.dropdown-btn.active').next('.sub-menu').slideUp('slow');
    //         jQuery('.dropdown-btn.active').removeClass('active');
    //         jQuery(this).next('.sub-menu').slideDown('slow');
    //         jQuery(this).addClass('active');
    //     }

    // });
    jQuery('.dropdown-btn').on('click', function () {
        if (jQuery(this).hasClass('active')) {
            jQuery(this).next('.sub-menu').slideUp('slow');
            jQuery(this).removeClass('active');
        } else {
            var active_dropdown = jQuery(this).parent().siblings('.menu-item').find('.dropdown-btn.active');
            active_dropdown.next('.sub-menu').slideUp('slow');
            active_dropdown.removeClass('active');
            jQuery(this).next('.sub-menu').slideDown('slow');
            jQuery(this).addClass('active');
        }

    });

    // Sidebar Menu Open
    jQuery('.hamburger').on('click', function () {
        jQuery('.navbar').toggleClass('open');
        jQuery(this).toggleClass('open');
    });
    // Back to top
    jQuery('.back-to-top').on('click', function () {
        jQuery('html,body').animate({ scrollTop: 0 }, 1000);
    });

    var slider = jQuery('.post-slider.owl-carousel');
    slider.owlCarousel({
        nav: true,
        dots: false,
        loop: true,
        items: 1,
        smartSpeed: 450,
        responsiveClass: true,
        responsive: {
            0: {
                nav: false,
            },
            600: {
                nav: false,
            },
            1000: {
                nav: true,
            }
        }
    });
});
