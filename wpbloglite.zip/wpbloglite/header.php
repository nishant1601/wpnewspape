<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="page" class="site">
    <header id="header" class="header header-default" role="header">
        <div class="container">
            <div class="row">
                <div class="custom-logo">
                    <a href="<?php echo site_url(); ?>" title="<?php bloginfo( 'name' ); ?>">
                        <img src="<?php echo wp_get_attachment_image_src( get_theme_mod('custom_logo'),'full')[0]; ?>" alt="<?php bloginfo( 'name' ); ?>">
                    </a>
                </div>
                <?php wp_nav_menu( array(
                    'menu'              =>  'primary',
                    'location'          =>  'primary',
                    'container'         =>  'nav',
                    'container_class'   =>  'navbar navbar-default',
                    'menu_after'        =>  '<span class="arrow-down">v</span>',
                ) ); ?>
                <div class="humburger-wrapper">
                    <div class="hamburger">
                        <div class="bar"></div>
                        <div class="bar"></div>
                        <div class="bar"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>