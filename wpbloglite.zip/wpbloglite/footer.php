    <div class="contact-info">
        <ul class="contact-list">
            <li><a href="">Facebook</a></li>
            <li><a href="#">Email</a></li>
            <li><a href="#">Upwork</a></li>
        </ul>
    </div>
    <footer class="footer footer-default" role="widget-area">
        <div class="container-fluid">
            <div class="row">
                <?php if(is_active_sidebar( 'sidebar-2' )): ?>
                <div class="widget-area">
                    <?php dynamic_sidebar( 'sidebar-2' ) ?>
                </div>
                <?php endif; ?>
                <?php if(is_active_sidebar( 'sidebar-3' )): ?>
                <div class="widget-area">
                    <?php dynamic_sidebar( 'sidebar-3' ) ?>
                </div>
                <?php endif; ?>
                <?php if(is_active_sidebar( 'sidebar-4' )): ?>
                <div class="widget-area">
                    <?php dynamic_sidebar( 'sidebar-4' ) ?>
                </div>
                <?php endif; ?>
                <?php if(is_active_sidebar( 'sidebar-5' )): ?>
                <div class="widget-area">
                    <?php dynamic_sidebar( 'sidebar-5' ) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </footer>
    <div class="copyright-credits">
        <p>&copy; <a href="#">Crikle Studio</a>-2019</p>
    </div>
</div>
<button type="button" class="back-to-top">Top</button>
<?php wp_footer(); ?>
</body>
</html>