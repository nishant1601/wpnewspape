<?php get_header(); ?>
<div id="content" class="site-content">
    <div class="container">
        <div class="row">
            <div id="primary" class="content-area">
                <main id="main" class="site-main" role="main">
                <?php get_template_part('/template-parts/page/content','404'); ?>
                </main>
            </div>
            <div id="secondary" class="sidebar">
            <?php wp_nav_menu( array(
                    'menu'              => '404',
                    'location'          => '404',
                ) ); ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); 
?>