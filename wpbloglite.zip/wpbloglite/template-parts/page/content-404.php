<div <?php post_class('text-center'); ?>>
    <h1 class="not-found">404 <span><?php echo __('Not found','wpbloglite') ?></span></h1>
    <p><?php echo __('I think what you\'re looking for doesn\'t exist. Use search to find something similar','wpbloglite') ?></p>
    <form role="search" method="get" id="searchform" class="searchform" action="http://localhost/fusion/">
        <div>
            <label class="screen-reader-text" for="s">Search for:</label>
            <input type="text" value="" name="s" id="s" placeholder="Search">
            <input type="submit" id="searchsubmit" value="Search">
        </div>
    </form>
</div>