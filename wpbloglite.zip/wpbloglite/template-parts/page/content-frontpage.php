<div <?php post_class(); ?>>
    <section class="slider-section">
        <div class="row">
            <div class="latest-post">
                <div class="post-slider owl-carousel">
                    <?php 
                    global $query;
                    $args = array(
                        'post_type'         =>  'post',
                        'orderby'           =>  'date',
                        'order'             =>  'DESC',
                        'posts_per_page'    =>  4,
                    );
                    $query = new WP_Query( $args );
                    if( $query->have_posts() ):
                        while( $query->have_posts() ): $query->the_post(); 
                    ?>
                    <article class="post-slide">
                        <div class="slider-image" style="background-image:url('<?php echo wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' )[0]; ?>')"></div>
                        <div class="img-overlay">
                            <a href="<?php the_permalink(); ?>"><h2><?php the_title(); ?></h2></a>
                        </div>
                    </article>
                    <?php   
                        endwhile;
                    else:
                        get_template_part('/template-parts/post/content','none');
                    endif;
                    wp_reset_query();
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
            <div class="post-categories">
                <?php
                $terms = get_terms(
                    'category', 
                    array(
                    'hide_empty' => false,
                    )
                );
                // print_r($terms);
                $html = '';
                $html .= '<ul>';
                foreach( $terms as $term ):
                $html .= '<li><a href=" ' . get_term_link( $term->term_id, $term->taxonomy ) . ' "> ' . $term->name . ' </a></li>';
                endforeach; 
                $html .= '</ul>';
                echo $html;
                ?>
            </div>
        </div>
    </section>
    <section class="all-post">
        <h2 class="section-title">Our Posts</h2>
        <div class="row">
            <?php 
            global $query;
            $args = array(
                'post_type'         =>  'post',
                'orderby'           =>  'date',
                'order'             =>  'DESC',
                'posts_per_page'    =>  4,
            );
            $query = new WP_Query( $args );
            if( $query->have_posts() ):
                while( $query->have_posts() ): $query->the_post(); 
            ?>
            <article class="post">
                <img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' )[0]; ?>')" />
                <div class="post-detail">
                    <a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
                    <p><?php the_excerpt(); ?></p>
                </div>
            </article>
            <?php   
                endwhile;
            else:
                get_template_part('/template-parts/post/content','none');
            endif;
            wp_reset_query();
            wp_reset_postdata();
            ?>
        </div>
    </section>
</div>