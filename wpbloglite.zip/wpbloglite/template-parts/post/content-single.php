<article <?php post_class(); ?>>
    <div class="featured-image">
        <img src="<?php echo wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' )[0]; ?>" alt="<?php the_title(); ?>">
    </div>
    <header class="entry-header">
    <a href="<?php the_permalink(); ?>"><h2 class="post-title"><?php the_title(); ?></h2></a>
    <div class="post-meta">
        <span><?php the_category( '|', get_the_ID() ); ?></span>
        <span><?php the_date( 'd F, Y', '<time>', '</time>'); ?></span>
        <span><?php the_author(); ?></span>
    </div>
    </header>
    <div class="entry-content">
    <p><?php the_content(); ?></p>
    </div>
    <!-- <hr class="post-separator"> -->
</article>