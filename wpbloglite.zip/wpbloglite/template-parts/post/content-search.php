<article <?php post_class(); ?>>
    <header class="entry-header">
    <a href="<?php the_permalink(); ?>"><h2 class="post-title"><?php the_title(); ?></h2></a>
    </header>
    <div class="entry-content">
    <p><?php the_excerpt(); ?></p>
    </div>
    <!-- <hr class="post-separator"> -->
</article>