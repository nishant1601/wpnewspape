<article <?php post_class('text-center'); ?>>
    <header class="entry-header">
    <h1 class="post-title not-found">
        NOT FOUND.
        <span>Posts are not available</span>
    </h1>
    </header>
    <p><?php echo __('I think what you\'re looking for doesn\'t exist. Use search to find something similar','wpbloglite') ?></p>
    <form role="search" method="get" id="searchform" class="searchform" action="http://localhost/fusion/">
        <div>
            <label class="screen-reader-text" for="s">Search for:</label>
            <input type="text" value="" name="s" id="s" placeholder="Search">
            <input type="submit" id="searchsubmit" value="Search">
        </div>
    </form>
    <!-- <hr class="post-separator"> -->
</article>